<section id="content">
    <h1>Comanda dvs este:</h1>

        <table border="1">
            <tr>
                <td> Numar bucati</td>
                <td> Carte </td>
                <td> Pret </td>
                <td> Total </td>
            </tr>
            <?php for($i=0; $i<count($_SESSION['id_produs']); $i++): ?>
                <?php if($_SESSION['nr_buc'][$i]>0): ?>
            <tr><td>
              <?=$_SESSION['nr_buc'][$i]?>
                </td><td><b>
                        <?=$_SESSION['den_prod'][$i]?></b> de <?=$_SESSION['den_producator'][$i]?></td><td><?=$_SESSION['pret'][$i]?> lei </td><td><?=$achizitie[$i]?> lei
                </td></tr>
                    <?php endif; ?>
            <?php endfor; ?>

            <tr><td colspan="3"><b>Total cumparaturi</b></td><td><b><?=$total?></b> lei </td></tr>
        </table>
    <form action="prelucrare.php" method="post">
        <table>
            <tr>
                <td> Numele:</td>
                <td> <input type="text" name="nume"  /> </td>
            </tr>
            <tr>
                <td> Adresa </td>
                <td> <textarea name="adresa" rows="7"></textarea></td>
            </tr>
            <tr>
                <td></td>
                <td> <input type="submit" value="Trimite" /></td>
            </tr>
        </table>
    </form>
</section>