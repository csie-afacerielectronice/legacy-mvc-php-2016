<section class="sidebar right">
    <h3>
        Lorem ipsum
    </h3>
    <p>
        Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan.
    </p>
</section>
</section>
</main>