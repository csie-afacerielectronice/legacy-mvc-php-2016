<main>
    <section>
        <section class="sidebar left">
            <ul>

                <?php foreach ($categorii as $cat): ?>
                    <li><a href="categorie.php?den_categorie=<?=$cat?>"><?=$cat?></a></li>
                <?php endforeach; ?>
                <section>
                    <form action="cautare.php" method="GET">
                        <b> Cautare </b><br />
                        <input type="text" name="cuvant" size="10" /> <br />
                        <input type="submit" value="Cauta"  />
                    </form>
                </section>
            <!--
                <li><a href="#">Link 1</a></li>
                <li><a href="#">Link 2</a></li>
                <li><a href="#">Link 3</a></li>
                <li><a href="#">Link 4</a></li>
            -->
            </ul>
        </section>