<?php
/**
 * Created by PhpStorm.
 * User: Radu.Constantinescu
 * Date: 19/11/2014
 * Time: 18:52
 */
include("includes/conectare.php");
include("includes/top.php");
include("services/categoriiService.php");
include("services/contentService.php");
include("includes/meniu.php");
include("views/content.php");
include("includes/right.php");
include("includes/footer.php");
