<?php
/**
 * Created by PhpStorm.
 * User: Radu.Constantinescu
 * Date: 20/11/2014
 * Time: 12:28
 */
                $categorii = array();
                $sql="select * from categorii";
                $res=mysql_query($sql);
                while($row=mysql_fetch_array($res, MYSQL_ASSOC)){
                    //print '<li><a href="categorie.php?den_categorie= '.$row['den_categorie'].'">'.$row['den_categorie'].'</a></li>';
                    $categorii[] = $row['den_categorie'];

                };
