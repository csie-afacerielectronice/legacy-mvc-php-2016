<?php
/**
 * Created by PhpStorm.
 * User: Radu.Constantinescu
 * Date: 20/11/2014
 * Time: 12:39
 */
    $adreseImagini = array();
    $denProduse = array();
    $idProduse = array();
    $denProducatori = array();
    $preturi = array();
    $sql = "select id_produs, den_prod, den_producator, pret from produse, producatori where produse.id_producator=producatori.id_producator order by id_produs desc limit 0,3";
    $res = mysql_query($sql);
    while($row=mysql_fetch_array($res)){
        $adreseImagini[] = "cover/".$row['id_produs'].".jpg";
        $denProduse[]= $row['den_prod'];
        $idProduse[]= $row['id_produs'];
        $denProducatori[] = $row['den_producator'];
        $preturi[] = $row['pret'];
    }
