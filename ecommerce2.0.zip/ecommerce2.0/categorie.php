<?php
include("includes/conectare.php");
$sql="select den_prod from produse, categorii where den_categorie='".$_GET['den_categorie']."' and categorii.id_categorie=produse.id_categorie";
$res=mysql_query($sql);
$nr=mysql_num_rows($res);
print '<h3> Sunt '.$nr.' produse in categoria '.$_GET['den_categorie'].'</h3>';
print "<h4> Produsele din domeniu:</h4>";
while($row=mysql_fetch_array($res, MYSQL_BOTH)){
    print $row['den_prod'].'<br>';
}
