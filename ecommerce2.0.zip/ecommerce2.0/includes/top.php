<!doctype html>
<html>
<head>
    <title>ECOMMERCE DEMO</title>
    <link rel="stylesheet" href="fonts/fonts.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/jquery-1.11.1.min.js"></script>
</head>
<body>
<div id="container">
    <header>
        <section id="logo">
            <h1>
                Site name
            </h1>
        </section>
        <section id="navigation">
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="#">Link 2</a></li>
                <li><a href="#">Link 3</a></li>
                <li><a href="#">Link 4</a></li>
            </ul>
        </section>
    </header>