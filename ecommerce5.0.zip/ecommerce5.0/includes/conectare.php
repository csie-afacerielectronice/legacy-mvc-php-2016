<?php
/**
 * Created by PhpStorm.
 * User: Radu.Constantinescu
 * Date: 19/11/2014
 * Time: 18:54
 */

//if (mysql_connect("localhost", "root","")){echo "Conectare reusita";}
mysql_connect("localhost", "root","root");
mysql_select_db("magazin");
include("services/autorizareService.php");