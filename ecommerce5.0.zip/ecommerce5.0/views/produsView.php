<section id="content">
    <?php if(file_exists($adresaImagine)): ?>
        <img src="<?=$adresaImagine?>" width="70" height="90"><br />
    <?php else: ?>
        <div style="width:70px, heigth:90px"> Imagine lipsa </div>
    <?php endif; ?>
    <div>
        <h1>
            <?=$denProd?>
        </h1>
        <i>de
            <?=$denProducator?>
        </i>
        <p><i>
                <?=$descriere?>
            </i></p>
        <p>Pret:
            <?=$pret?>
            lei</p>
        <form action="cos.php?actiune=adauga" method="post">
            <input type="hidden" name="id_produs" value="<?=$id_cart?>"  />
            <input type="hidden" name="den_prod" value="<?=$denProd?>"  />
            <input type="hidden" name="den_producator" value="<?=$denProducator?>"  />
            <input type="hidden" name="pret" value="<?=$pret?>"  />
            <input type="submit" value="Cumpara"  />
        </form>
        <br />
        <br />
        <p>
            <b>
                Comentariile cititorilor
            </b>
        </p>
        <?php for($i=0; $i<count($emailuri); $i++): ?>
            <div style=width="300"><a href="mailto:<?=$emailuri[i]?>"><?=$utilizatori[$i]?></a><br /><?=$comentarii[$i]?></div>
        <?php endfor; ?>
    </div>
    <br />
    <br />
    <div style="width:400px">
        <h2>
            Adauga o opinie </h2>
        <form action="adauga_comentariu.php" method="post">
            Nume: <input type="text" name="nume_utilizator" />
            email: <input type="text" name="adresa_email" />
            comentariu: <textarea name="comentariu" cols="45"></textarea> <br /><br  />
            <input type="hidden" name="id_produs" value="<?=$id_cart?>" />
            <input type="submit" value="Adauga" />
        </form>
    </div>
</section>
