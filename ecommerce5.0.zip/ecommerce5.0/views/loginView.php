<?php

if (empty($erori)): ?>

    <td> <h1>Sunteti logat</h1> </td>
<?php

else:
    foreach ($erori as $e)
    {
        echo "<div>".$e."</div>"."<a href=\"index.php\">Back</a>";
    }

endif;
?>