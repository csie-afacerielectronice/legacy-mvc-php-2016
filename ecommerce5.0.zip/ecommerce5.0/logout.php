<?php
/**
 * Created by PhpStorm.
 * User: radu.constantinescu
 * Date: 05/12/14
 * Time: 17:53
 */
session_start();
unset($_SESSION['auth']);
header("Location:index.php");