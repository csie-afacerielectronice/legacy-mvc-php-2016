<?php
/**
 * Created by PhpStorm.
 * User: radu.constantinescu
 * Date: 25/11/14
 * Time: 12:48
 */
$eroriA = array();
$logat = false;
session_start();
if($_SESSION['auth']['key'] != session_id()){
    $eroriA[] = "Acces neautorizat";

}
else {
    $sql = "select * from conturi where nume='" . $_SESSION['auth']['nume'] . "' and parola='" . $_SESSION['auth']['parola'] . "'";
    $res = mysql_query($sql);
    if (mysql_num_rows($res) != 1) {
        $eroriA[] = "Acces neautorizat";
    }
    else{
        $logat = true;

    }
}
?>