<?php
$denProduseCategorie = array();
$idProduseCategorie = array();

$sql="select id_produs, den_prod from produse, categorii where den_categorie='".$_GET['den_categorie']."' and categorii.id_categorie=produse.id_categorie";
$res=mysql_query($sql);
$nr=mysql_num_rows($res);
while($row=mysql_fetch_array($res, MYSQL_BOTH))
{
    $denProduseCategorie[] = $row['den_prod'];
    $idProduseCategorie[] = $row['id_produs'];
}