<?php
    $tranzactie = "insert into tranzactii(nume_cumparator, adresa_cumparator) values('".$_POST['nume']."','".$_POST['adresa']."')";
    $res = mysql_query($tranzactie);
    $id_tranzactie = mysql_insert_id();
    for($i=0;$i<count($_SESSION['id_produs']);$i++) {
        if($_SESSION['nr_buc'][$i]>0) {
            $sql_vanzare="insert into vanzari values('".$id_tranzactie."','".$_SESSION['id_produs'][$i]."','".$_SESSION['nr_buc'][$i]."')";
            mysql_query($sql_vanzare); } }
?>
