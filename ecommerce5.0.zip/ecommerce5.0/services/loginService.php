<?php

$erori = array();

if(empty($_POST['nume']) || empty($_POST['parola'])) {
    $erori[]="Date de conectare incomplete";
}
else
    {
        $parola = md5($_POST['parola']);
        $sql = "select * from conturi where nume='" . $_POST['nume'] . "'and parola='" . $parola . "'";
        $res = mysql_query($sql);
        if (mysql_num_rows($res) != 1) {
            $erori[] = "Date de conectare incorecte";
        }
        else {
            session_start();
            $AUTH = array(
                'nume'=>$_POST['nume'], 'parola'=>$parola,'key'=>session_id()

            );
            $_SESSION['auth'] = $AUTH;
            $logat = true;
//
//            $_SESSION['nume'] = $_POST['nume'];
//            $_SESSION['parola'] = $parola;
//            $_SESSION['key_admin'] = session_id();
        }
    }
?>
