<?php
    include("includes/conectare.php");
    $err = array();
    if(empty($_POST['nume'])) $err[] = "Nume necompletat";
    if(empty($_POST['adresa'])) $err[] = "Adresa necompletata";
    session_start();
    $numar_produse = $cart->cartNotEmpty();
    if($numar_produse == 0) $err[] = "Trebuie cumparat macar un produs";
    if (empty($err)) {
        include("services/inregistrareService.php");
        session_unset();
        session_destroy();
        $logat = false;
    }

    include("services/categoriiService.php");
    include ("includes/top.php");
    include ("includes/meniu.php");
    include("views/inregistrareView.php");
    include("includes/right.php");
    include ("includes/footer.php");
?>
