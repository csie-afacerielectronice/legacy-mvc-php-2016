<section id="content">
    <h1>Cosul de cumparaturi</h1>
    <form action="cos.php?actiune=modifica" method="post">
        <table border="1">
            <tr>
                <td> Numar bucati</td>
                <td> Carte </td>
                <td> Pret </td>
                <td> Total </td>
            </tr>
            <?php
            $total = 0;
            foreach ($produse_cos as $produs): ?>

                <?php if($produs['nr_buc']>0): ?>

                    <tr> <td>
                            <input type="text" name="noulNr[]" size="2" value="<?=$produs['nr_buc']?>">
                            <input type="hidden" name="id_prod[]" value="<?=$produs['id']?>""
                        </td>

                        <td>
                            <b><?=$produs['den_prod']?></b> de <?=$produs['den_producator']?></td><td><?=$produs['pret']?> lei </td><td><?=$produs['pret']*$produs['nr_buc']?> lei
                            <?php $total += $produs['pret']*$produs['nr_buc']; ?>
                        </td>

                    </tr>



                <?php endif; ?>

            <?php endforeach; ?>


            <tr><td colspan="3"><b>Total cumparaturi</b></td><td><b><?=$total?></b> lei </td></tr>
        </table>
        <input type="submit" value="Modifica"> <br /> <br />
        <h1> Continuare</h1>
        <a href="index.php"> Continua cumparaturile </a>
        <a href="casa.php"> Efectueaza plata </a>
    </form>
</section>