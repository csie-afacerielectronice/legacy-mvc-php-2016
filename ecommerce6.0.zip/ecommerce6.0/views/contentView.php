<section id="content">
    <h2> Cele mai noi carti </h2><br /><br />

    <?php for ($i=0; $i<count($adreseImagini); $i++): ?>
        <?php if (file_exists($adreseImagini[$i])): ?>
            <img src="<?=$adreseImagini[$i]?>" width="70" height="90"><br />
        <?php else: ?>
            <div style="width:70px, heigth:90px"> <br />Imagine lipsa <br /></div>
        <?php endif; ?>

        <div>
            <b>
                <a href="produs.php?id_produs=<?=$idProduse[$i]?>">
                    <?=$denProduse[$i]?>
                </a>
            </b> <br />
            produsa de
            <i>
                <?=$denProducatori[$i]?>
            </i> <br />
            pret:<?=$preturi[$i]?>lei
        </div>
    <?php endfor; ?>

</section>