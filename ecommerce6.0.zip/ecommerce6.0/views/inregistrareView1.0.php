<?php if(empty($_POST['nume'])): ?>
    <div> Trebuie completat numele <a href="cos.php">Back</a> </div>
        <?php else: ?>


        <?php if(empty($_POST['adresa'])): ?>
        <div> Trebuie completata adresa <a href="cos.php">Back</a> </div>
            <?php else:
                session_start();
                $numar_produse = array_sum($_SESSION['nr_buc']);
                ?>
                <?php if($numar_produse == 0): ?>

                    <div> Trebuie cumparat cel putin un produs <a href="cos.php">Back</a></div>
                    <?php else: ?>

                <td> <h1>Multumim pentru cumparaturi</h1> </td>
                <?php
                include ("services/inregistrareService.php");
                session_unset();
                session_destroy();
                ?>
                <?php endif; ?>
                <?php endif; ?>

    <?php endif; ?>


