<section id="content">
    <h2> Produse categorie </h2><br /><br />

    <?php for ($i=0; $i<count($idProduseCategorie); $i++): ?>
        <div>
            <b>
                <a href="produs.php?id_produs=<?=$idProduseCategorie[$i]?>">
                    <?=$denProduseCategorie[$i]?>
                </a>
            </b>
        </div>
    <?php endfor; ?>

</section>