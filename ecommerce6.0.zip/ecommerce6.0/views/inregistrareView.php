<?php
if (empty($err)): ?>

    <td> <h1>Multumim pentru cumparaturi</h1> </td>
    <?php

    else:
        foreach ($err as $e)
         {
             echo "<div>".$e."</div>"."<a href=\"cos.php?actiune=vizualizeaza\">Back</a>";
         }

endif;
?>