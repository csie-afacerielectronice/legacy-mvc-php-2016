<?php
session_start();
include("includes/conectare.php");
include("services/categoriiService.php");
include("services/totalService.php");
include ("includes/top.php");
include ("includes/meniu.php");
$produse_cos = $cart->getCart();
include("views/casaView.php");
include("includes/right.php");
include ("includes/footer.php");
?>