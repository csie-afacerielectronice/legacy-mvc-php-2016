-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 24, 2014 at 11:32 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `magazin`
--
CREATE DATABASE `magazin` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `magazin`;

-- --------------------------------------------------------

--
-- Table structure for table `categorii`
--

CREATE TABLE IF NOT EXISTS `categorii` (
  `id_categorie` smallint(5) NOT NULL AUTO_INCREMENT,
  `den_categorie` varchar(30) DEFAULT NULL,
  `descriere` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_categorie`),
  KEY `id_categorie` (`id_categorie`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `categorii`
--

INSERT INTO `categorii` (`id_categorie`, `den_categorie`, `descriere`) VALUES
(1, 'carti', 'beletristica, literatura tehnica'),
(2, 'muzica', 'pop, rock, electro');

-- --------------------------------------------------------

--
-- Table structure for table `comentarii`
--

CREATE TABLE IF NOT EXISTS `comentarii` (
  `id_comentariu` smallint(5) unsigned NOT NULL,
  `id_produs` smallint(5) unsigned NOT NULL,
  `utilizator` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `comentariu` varchar(500) NOT NULL,
  KEY `id_comentariu` (`id_comentariu`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comentarii`
--

INSERT INTO `comentarii` (`id_comentariu`, `id_produs`, `utilizator`, `email`, `comentariu`) VALUES
(1, 1, 'ion ionescu', 'ion@ion.ro', 'excelent'),
(2, 2, 'vasile popescu', 'vasile@vasile.ro', 'foarte multumit');

-- --------------------------------------------------------

--
-- Table structure for table `producatori`
--

CREATE TABLE IF NOT EXISTS `producatori` (
  `id_producator` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `den_producator` varchar(50) DEFAULT NULL,
  `descriere` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_producator`),
  KEY `id_producator` (`id_producator`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `producatori`
--

INSERT INTO `producatori` (`id_producator`, `den_producator`, `descriere`) VALUES
(1, 'teora', NULL),
(2, 'ase', NULL),
(3, 'electrecord', NULL),
(4, 'sony', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `produse`
--

CREATE TABLE IF NOT EXISTS `produse` (
  `id_produs` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_producator` smallint(5) DEFAULT NULL,
  `id_categorie` smallint(5) DEFAULT NULL,
  `den_prod` varchar(30) DEFAULT NULL,
  `descriere` varchar(100) DEFAULT NULL,
  `pret` int(11) NOT NULL,
  PRIMARY KEY (`id_produs`),
  KEY `id_produse` (`id_produs`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `produse`
--

INSERT INTO `produse` (`id_produs`, `id_producator`, `id_categorie`, `den_prod`, `descriere`, `pret`) VALUES
(1, 1, 1, 'programare in C++; Smeureanu', 'Introducere', 10),
(2, 3, 2, 'Vivaldi, Anotimpurile', 'muzica clasica', 20);

-- --------------------------------------------------------

--
-- Table structure for table `tranzactii`
--

CREATE TABLE IF NOT EXISTS `tranzactii` (
  `id_tranzactie` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data_tranzactie` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nume_cumparator` text NOT NULL,
  `adresa_cumparator` text NOT NULL,
  UNIQUE KEY `id_tranzactie` (`id_tranzactie`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tranzactii`
--

INSERT INTO `tranzactii` (`id_tranzactie`, `data_tranzactie`, `nume_cumparator`, `adresa_cumparator`) VALUES
(1, '2011-04-04 18:06:27', 'andrei', 'test'),
(2, '2013-10-24 15:04:22', 'radu', 'bucuresti'),
(3, '2013-10-29 18:08:30', 'radu', 'test'),
(4, '2013-10-29 18:28:21', 'numre', 'adresa'),
(5, '2013-10-29 19:42:30', 'radu', 'radu'),
(6, '2013-10-30 18:22:40', 'radu', 'test'),
(7, '2013-10-30 19:36:35', 'radu', 'jjj'),
(8, '2014-11-23 18:37:00', 'radu', 'test'),
(9, '2014-11-23 18:37:51', 'radu', 'test'),
(10, '2014-11-24 11:04:17', 'radu', 'adresa'),
(11, '2014-11-24 11:17:07', '', ''),
(12, '2014-11-24 11:21:55', 'test', 'test 5'),
(13, '2014-11-24 11:34:54', 'test 6', 'test 6');

-- --------------------------------------------------------

--
-- Table structure for table `vanzari`
--

CREATE TABLE IF NOT EXISTS `vanzari` (
  `id_tranzactie` int(10) unsigned NOT NULL,
  `id_produs` int(10) unsigned NOT NULL,
  `nr_buc` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_tranzactie`,`id_produs`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vanzari`
--

INSERT INTO `vanzari` (`id_tranzactie`, `id_produs`, `nr_buc`) VALUES
(1, 2, 1),
(2, 1, 5),
(2, 2, 1),
(3, 2, 1),
(3, 0, 1),
(4, 2, 1),
(4, 1, 5),
(5, 1, 2),
(6, 2, 1),
(6, 1, 3),
(7, 1, 5),
(7, 2, 2),
(8, 2, 10),
(8, 1, 1),
(9, 2, 1),
(10, 1, 1),
(10, 2, 1),
(12, 2, 1),
(13, 2, 1);
