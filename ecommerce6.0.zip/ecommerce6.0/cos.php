<?php
    session_start();
    include("includes/conectare.php");
   // include("services/autorizareService.php");
    include("services/categoriiService.php");
    include ("includes/top.php");
    include ("includes/meniu.php");
    if (empty($eroriA))
    {

        include("services/cosService.php");
        $produse_cos = $cart->getCart();
        include("views/cosView.php");
    }
    else {
        include("views/neautorizatView.php");
    }
    include("includes/right.php");
    include ("includes/footer.php");
?>
