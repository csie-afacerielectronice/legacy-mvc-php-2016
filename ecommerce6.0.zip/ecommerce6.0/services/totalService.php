<?php
/**
 * Created by PhpStorm.
 * User: Radu.Constantinescu
 * Date: 23/11/2014
 * Time: 19:10
 */
//$achizitie = array();
//$total = 0;
//for($i=0; $i<count($_SESSION['id_produs']);$i++)
//{
//    $achizitie[] = $_SESSION['nr_buc'][$i]*$_SESSION['pret'][$i];
//    $total=$total+$achizitie[$i];
//
//}
?>