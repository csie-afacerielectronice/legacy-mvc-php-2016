<?php
    $tranzactie = "insert into tranzactii(nume_cumparator, adresa_cumparator) values('".$_POST['nume']."','".$_POST['adresa']."')";
    $res = mysql_query($tranzactie);
    $id_tranzactie = mysql_insert_id();
    foreach ($cart->getCart() as $p){
        $sql_vanzare="insert into vanzari values('".$id_tranzactie."','".$p['id']."','".$p['nr_buc']."')";
        mysql_query($sql_vanzare);

    }
//    for($i=0;$i<count($_SESSION['id_produs']);$i++) {
//        if($_SESSION['nr_buc'][$i]>0) {
//            $sql_vanzare="insert into vanzari values('".$id_tranzactie."','".$_SESSION['id_produs'][$i]."','".$_SESSION['nr_buc'][$i]."')";
//            mysql_query($sql_vanzare); } }
?>
