<?php
    $emailuri = array();
    $utilizatori = array();
    $comentarii = array();

    //preluare detalii produs
    $id_cart = $_GET['id_produs'];
    $sql2 = "select den_prod, den_producator, produse.descriere, pret from produse, producatori where id_produs=".$id_cart." and produse.id_producator = producatori.id_producator";
    $res2 = mysql_query($sql2);
    $row2 = mysql_fetch_array($res2);
    $adresaImagine = "cover/".$id_cart.".jpg";
    $denProd = $row2['den_prod'];
    $denProducator = $row2['den_producator'];
    $descriere = $row2['descriere'];
    $pret = $row2['pret'];

    //preluare comentarii
    $sql3 = "select * from comentarii where id_produs=$id_cart";
    $res3 = mysql_query($sql3);
    while($row3=mysql_fetch_array($res3))
    {
        $emailuri[] =$row3['email'];
        $utilizatori[] = $row3['utilizator'];
        $comentarii[] = $row3['comentariu'];
    }
?>
