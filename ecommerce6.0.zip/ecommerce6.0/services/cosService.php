<?php

    $actiune=$_GET['actiune'];
    if(isset($_GET['actiune']) && $_GET['actiune']=="adauga")
    {
    //initializeaza/completeaza masivul bidimensional al variabilelor de sesiune cu valorile trimise din formularul de pe pagina carte.php

        $cart->addToCart($_POST['id_produs'], $_POST['den_prod'], $_POST['pret'], 1, $_POST['den_producator']);

//        $_SESSION['id_produs'][]=$_POST['id_produs'];
//        $_SESSION['nr_buc'][]=1;
//        $_SESSION['pret'][]=$_POST['pret'];
//        $_SESSION['den_prod'][]=$_POST['den_prod'];
//        $_SESSION['den_producator'][]=$_POST['den_producator'];
   }
    if(isset($_GET['actiune']) && $_GET['actiune']=="modifica")
    {
        //modifica numarul de bucati comandate conform cu datele din formularul de mai jos

        for($i=0; $i<count($_POST['id_prod']);$i++)
        {
            $cart->updateCart($_POST['id_prod'][$i],$_POST['noulNr'][$i]);
        }
    }
//    include("totalService.php");
?>
