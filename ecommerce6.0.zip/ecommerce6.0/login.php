<?php
/**
 * Created by PhpStorm.
 * User: radu.constantinescu
 * Date: 25/11/14
 * Time: 12:33
 */
include("includes/conectare.php");
$erori = array();
if(empty($_POST['nume']) || empty($_POST['parola'])) {
    $erori[]="Date de conectare incomplete";
}
include("services/loginService.php");

//session_start();
//$_SESSION['nume'] = $_POST['nume'];
//$_SESSION['parola'] = $parola;
//$_SESSION['key_admin'] = session_id();

include("services/categoriiService.php");
include ("includes/top.php");
include ("includes/meniu.php");
include("views/loginView.php");
include("includes/right.php");
include ("includes/footer.php");
?>