<?php
/**
 * Created by PhpStorm.
 * User: radu.constantinescu
 * Date: 29/01/15
 * Time: 09:33
 */

class cart {
    public static $cart;
    public function __construct(){
        @session_start();
        self::$cart = array();
        if ($_SESSION['cart']){
            self::$cart = $_SESSION['cart'];
        }

    }
    public function addToCart($id_produs, $den_prod, $pret, $nr_buc, $den_producator){

        foreach (self::$cart as $p){
            if($p['id'] == $id_produs){
                $this->updateCart($id_produs, $p['nr_buc']+1);
                return 1;
        }

        }

        $produs = array(
            'id' => $id_produs,
            'den_prod' => $den_prod,
            'pret' => $pret,
            'nr_buc' => $nr_buc,
            'den_producator' => $den_producator
        );
        self::$cart[] = $produs;
    }

    public function __destruct(){
        $_SESSION['cart'] = self::$cart;
    }

    public function getCart(){
        return self::$cart;
    }

    public function updateCart($id_prod, $volume){
        foreach (self::$cart as &$produs){
            if($produs['id'] == $id_prod){
                if($produs['nr_buc'] >0)
                    $produs['nr_buc'] = $volume;
                else unset($produs);
            }

        }

    }
    public function cartNotEmpty(){
        return count(self::$cart);

    }
}
