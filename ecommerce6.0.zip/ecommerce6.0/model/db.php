<?php
/**
 * Created by PhpStorm.
 * User: radu.constantinescu
 * Date: 22/01/15
 * Time: 09:05
 */

class db {
    private static $handle;
    private $host, $user, $pass, $dbname;
    public function __construct($host, $user, $pass, $dbname){
        $this->host = $host;
        $this->user = $user;
        $this->pass = $pass;
        $this->dbname = $dbname;
        $this->connect();
    }

    private function connect(){
        self::$handle = mysql_connect($this->host, $this->user,$this->pass);
        if (! self::$handle){
            die('Conectare esuata'.mysql_error());
        }
        if(! mysql_select_db($this->dbname, self::$handle)){

            die("Selectie baza de date esuata". mysql_error());
        }
    }

    public function query($sql){
        $result = mysql_query($sql, self::$handle);
        return $result;
    }
} 