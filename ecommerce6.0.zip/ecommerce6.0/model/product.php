<?php
/**
 * Created by PhpStorm.
 * User: radu.constantinescu
 * Date: 29/01/15
 * Time: 09:40
 */

class product {
    private $id;
} 