<?php
    session_start();
    include("includes/conectare.php");
    include("services/categoriiService.php");
    include("services/productService.php");
    include ("includes/top.php");
    include ("includes/meniu.php");
    include("views/produsView.php");
    include("includes/right.php");
    include ("includes/footer.php");
?>
