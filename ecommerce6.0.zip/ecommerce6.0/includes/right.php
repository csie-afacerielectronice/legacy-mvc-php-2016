<section class="sidebar right">


<?php if(!$logat): ?>
    <div> Login to shop</div>
    <form action="login.php" method="post">
        <input type="text" name="nume" />
        <br />
        <input type="password" name="parola" />
        <br />
        <input type="submit" value="Submit" />

    </form>
<?php else: ?>
    <a href="logout.php">Logout</a>
<?php endif; ?>
</section>
</section>
</main>