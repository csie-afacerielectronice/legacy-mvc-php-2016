<?php
/**
 * Created by PhpStorm.
 * User: Radu.Constantinescu
 * Date: 19/11/2014
 * Time: 18:54
 */

include("config.php");
include("model/db.php");
include("model/cart.php");
$db = new db (DB_SERVER, DB_USER,DB_PASS, DB_DATABASE);
$cart = new cart();
include("services/autorizareService.php");