<?php
/**
 * Created by PhpStorm.
 * User: radu.constantinescu
 * Date: 22/01/15
 * Time: 09:27
 */

define("DB_SERVER","localhost");
define("DB_USER","root");
define("DB_PASS","root");
define("DB_DATABASE","magazin");
