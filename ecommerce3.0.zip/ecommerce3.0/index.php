<?php
/**
 * Created by PhpStorm.
 * User: Radu.Constantinescu
 * Date: 19/11/2014
 * Time: 18:52
 */
include("includes/conectare.php");
include("services/categoriiService.php");
include("services/contentService.php");
include("includes/top.php");
include("includes/meniu.php");
include("views/contentView.php");
include("includes/right.php");
include("includes/footer.php");
