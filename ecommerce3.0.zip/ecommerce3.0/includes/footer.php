<footer>
    Copyright &copy; 2014
</footer>
</div>
</body>
</html>