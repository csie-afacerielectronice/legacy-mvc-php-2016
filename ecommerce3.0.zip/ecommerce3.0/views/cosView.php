<section id="content">
    <h1>Cosul de cumparaturi</h1>
    <form action="cos.php?actiune=modifica" method="post">
        <table border="1">
            <tr>
                <td> Numar bucati</td>
                <td> Carte </td>
                <td> Pret </td>
                <td> Total </td>
            </tr>
            <?php for($i=0; $i<count($_SESSION['id_produs']); $i++): ?>
            <tr><td>
                    <input type="text" name="nouNr[<?=$i?>]" size="2" value="<?=$_SESSION['nr_buc'][$i]?>">
                </td><td><b>
                        <?=$_SESSION['den_prod'][$i]?></b> de <?=$_SESSION['den_producator'][$i]?></td><td><?=$_SESSION['pret'][$i]?> lei </td><td><?=$achizitie[$i]?> lei
                </td></tr>
            <?php endfor; ?>

            <tr><td colspan="3"><b>Total cumparaturi</b></td><td><b><?=$total?></b> lei </td></tr>
        </table>
        <input type="submit" value="Modifica"> <br /> <br />
        <h1> Continuare</h1>
        <a href="index.php"> Continua cumparaturile </a>
        <a href="casa.php"> Efectueaza plata </a>
    </form>
</section>